//
//  IDCALayerVC.h
//  iOSDev
//
//  Created by XiaoShan on 2/27/16.
//  Copyright © 2016 XiaoShan. All rights reserved.
//

#import "IDBaseVC.h"

@interface IDCALayerVC : IDBaseVC

@end
